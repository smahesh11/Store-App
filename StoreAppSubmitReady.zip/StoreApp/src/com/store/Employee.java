package com.store;

public class Employee {
 public String firstName, password;Boolean isValid;
 public String getFirstName(){
	 return firstName;
 }
 public void setFirstName(String firstName){
	 this.firstName = firstName;
 }
 public String getPassword(){
	 return password;
 }
 public void setPassword(String password){
	 this.password = password;
 }
 public Boolean isValid(){
	 return isValid;
 }
 public void setIsValid(Boolean isValid){
	 this.isValid = isValid;
 }
 
}
